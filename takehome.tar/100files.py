#!/usr/bin/env python
## Author: Kiril Dubrovsky
## Date: 01/02/2018
## Description: Script to perform the following:
### This script generates 100 files with random data
#* Every 5th file contains "Nothing to see here".
#* Every 11th file contains the contents of all previous files.
#* Random data files do not exceed 512 characters in length.
#* You should implement tests.
 
import random
import string
import os
import glob

x = 1

while x < 101:
   filename = "file%d.txt"  % (x)
   f= open(filename,"w+")
   ## Every 5th file should contain, "Nothing to see here."
   if x % 5 == 0:
      chars = "Nothing to see here."
   else:
       ## Every 11th file should contain the contents of all previous files
       if x % 11 == 0:
          filenames = glob.glob("file*.txt")
          for fname in filenames:
              with open(fname) as infile:
                #outfile.write(infile.read())
                f.write(infile.read())
          chars = ""
       else:
          ## All other files should contain a random string of data less than 512 characters. 
          chars = "".join( [random.choice(string.letters) for i in xrange(8)] )
   f.write(chars)
   x += 1
   f.close()

## Now Perfom a test. If there are not enough files, error
path, dirs, files = os.walk(".").next()
file_count = len(files)
if file_count < 100:
   print "Script failed"
else:
   print "We've made %d files" % file_count
