# Interview questions

## A few rules

* Feel free to use google.
* Don't copy code.
* Keep it short, I don't expect an essay.
* I tend to prefer answers in a git repo tarball.

### Order the following from the slowest to the fastest operation

* CPU register access
* memory access
* Context switch
* Disk access

### Explain the main differences between ext2 and ext3 ?

* Extended Filesystem versions for linux operating systems.
* Ext2 does not have the journaling feature. 
* Ext3 allows journaling which can protect from corruption on crashes. 
* Both Ext2 and ext3 have max file size of 2TB and max of 32TB filesystem size. 
* Ext4 is the current filesystem type for linux. It is much more performant and reliable. Ext4 supports up to 16TB file size and 1Exabyte filesystem. 

###  Explain the main differences between TCP and UDP ?

* TCP is a stateful protocol and UDP is stateless. TCP sends a request and waits for a response. It will not continue to send more information until it gets the response back.  UDP sends the information without waiting for confirmation of receipt. 

### Tell me of an alternative way of deleting files when:

* There are over 7 million files in a directory
* There are interesting files called: "--file", "-rf"
* there is no rm command available to you

If you can delete the directory, you can use rmdir
or 
find . -type f -delete

### List common commands for the following  tasks:

* Resource issue diagnostics

ps -ef

top

vmstat

free -m

* IO and IO/wait related dissues

iostat

* Networking and Packet loss

netstat
route
ping
telnet
tcpdump

### Explain in your opinion the differences and advantages/disadvantages between:

* Ansible

Ansible is currently my favorite tools to automate server creation and configuration management. Althought I am becoming more proficient in terraform and packer for the server creation automation. Ansible is a simple way to script server configuration and management. There are ansible modules that allow for the various cloud providers to quickly get servers running. 

* Puppet

Puppet is another way to automate server configuration. I find it to be a much steeper curve to learn and master than ansible, although it has more power and flexibility when it comes server configuration. Puppet does require an agent on the servers that are managed, where ansible uses ssh. 

* Python Fabric

Python Fabric is another tool to automate server management. Fabric, like ansible, manages servers via SSH and does not need an additional service. Fabric can do remote execution on a list of servers. I've found ansible to have more power and ease of use. 

### Explain in your opinion the differences and advantages/disadvantages between:

* CloudFormation

CFN was json, but recently allows yaml, and is a way to stack a list of resources to create in AWS. It is a tool provided by AWS, so only works in AWS. 

* Kubernetes

Kubernetes is a tool to build and manage clusters of servers  and pods of docker containers. Kubernetes is an open source tool originally created at Google. It can be used on any cloud provider.  In my opinion, kubernetes is the best way to manage clusters of docker containers. 

* Terraform

Terraform is a hashicorp tool that also can run on multiple cloud providers. In most cases, it's either terraform or cloudformation. Cloudformation nested stacking and passing variables back and forth between stacks and the problems those things cause is the reason I've switched to Terraform. I like terraform better for parameterizing pairing templates. 

### In your words what is Devops ?

* Devops is a buzz word that is supposed to be the pairing of development teams and operations teams. In the past, developers would bundle code and throw it over the wall to operations to make it work on production. Devops is meant to be a combination of responsibilities between the two teams to come together to speed delivery and make better products. In many cases, a "devops" team is introduced to effectively be the IT team for the automation tools. But I think Devops should be a combination of People, Processes and Technology to improve automation and leveraging tools for logs viewing, monitoring and continuous integration. Also to reduce feedback loops to get developers bugs quickly to enable all people involved to deploy, monitor and manage the production architecture. I've delivered a handful of presentations at devops meetups stressing the importance of monitoring, automation and communication in devops.  

### In your words what are microservices ?

* Microservices is a technique to split larger, more complicated applications into smaller applications. This allows for smaller, more agile development teams. From an operations perspective, it means more things can fail, but if monitoring and application management tools are in place then operations should have more control to isolate the problem and repair quickly or automate the recovery without impacting other services. 

## Exercises

### Generate 100 files with random data

* Every 5th file should contain "Nothing to see here".
* Every 11th file should contain the contents of all previous files.
* Random data files should not exceed 512 characters in length.
* You should implement tests.

In the base directory, there is a script, 100files.py

### Write terraform provider that

* Creates an EC2 instance with
  * The latest ubuntu LTS AMI
  * A Security Group enabling 22, 80, 443 only to 5.148.131.186/32
  * Using an S3 backend

There is a terraform directory with the necessesary files to create the requested resources. In order to get it running in your env, you just need to update the variables.tf to match the resources in your AWS account. And the instance.tf has instructions on how to setup the access and execute the template. If changes are made to the variables for region or s3 bucket, the statefile.tf will also need to be updated. 


### Write a Dockerfile for redis

* That accepts port configuration from ENV variables
* That accepts memory limit configuration from ENV variables

This is a confusing question. I normally set memory limits and port configurations in the docker-compose.yml or from the docker command line. I use the Dockerfile to build containers. I've included a docker directory with the docker-compose.yml and a .env script. Run the following to get it working:
source .env
docker-compose up -d